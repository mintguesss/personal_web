'use client'
import { useState, useEffect, useRef } from 'react'
import { siteData } from '@/data/portfolio'

const SLIDES = [
  '/personal_web/slides/Slide1.jpg',
  '/personal_web/slides/Slide2.jpg',
  '/personal_web/slides/Slide3.jpg',
  '/personal_web/slides/Slide4.jpg',
  '/personal_web/slides/Slide5.jpg',
]

const CAPTIONS = [
  '輔仁大學資訊管理系',
  '國科會大專生研究計畫',
  '騙局雷達 — 畢業專題',
  '育秀盃創意獎佳作',
  '即將升讀中央大學資訊管理研究所',
]

type EduHighlight = { label: string; items: readonly string[] }
type Edu = { school: string; dept: string; degree: string; period: string; badge: string; highlights: readonly EduHighlight[] }
type Exp = { role: string; company: string; period: string; desc: string; tags: readonly string[] }

export default function AboutPage() {
  const [current, setCurrent] = useState(0)
  const [fading, setFading] = useState(false)
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null)

  const goTo = (idx: number) => {
    if (idx === current) return
    setFading(true)
    setTimeout(() => { setCurrent(idx); setFading(false) }, 300)
  }

  useEffect(() => {
    timerRef.current = setTimeout(() => goTo((current + 1) % SLIDES.length), 4000)
    return () => { if (timerRef.current) clearTimeout(timerRef.current) }
  }, [current])

  const education = siteData.education as unknown as Edu[]
  const experience = siteData.experience as unknown as Exp[]

  return (
    <div style={{ paddingTop: '64px', minHeight: '100vh' }}>

      {/* ── 幻燈片：上下砍半、左右砍半置中 ── */}
      <div style={{ display: 'flex', justifyContent: 'center', padding: '0', background: 'var(--bg-2)', borderBottom: '1px solid var(--border)' }}>
        <div style={{ position: 'relative', width: '50%', height: 'clamp(400px,22vw,260px)', overflow: 'hidden' }}>
          <img
            key={current}
            src={SLIDES[current]}
            alt={CAPTIONS[current]}
            style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', objectFit: 'cover', objectPosition: 'center 30%', opacity: fading ? 0 : 1, transition: 'opacity 0.3s ease' }}
          />
          <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(to top, rgba(0,0,0,0.55) 0%, transparent 55%)' }} />
          <div style={{ position: 'absolute', bottom: '2rem', left: '1.5rem' }}>
            <p style={{ fontFamily: 'var(--font-mono)', fontSize: '0.7rem', letterSpacing: '0.15em', color: 'rgba(255,255,255,0.9)', textTransform: 'uppercase', opacity: fading ? 0 : 1, transition: 'opacity 0.3s' }}>{CAPTIONS[current]}</p>
          </div>
          <div style={{ position: 'absolute', bottom: '0.6rem', left: '1.5rem', display: 'flex', gap: '0.4rem' }}>
            {SLIDES.map((_, i) => (
              <button key={i} onClick={() => goTo(i)} style={{ width: i === current ? '20px' : '6px', height: '6px', borderRadius: '99px', border: 'none', cursor: 'pointer', background: i === current ? '#fff' : 'rgba(255,255,255,0.4)', transition: 'all 0.3s', padding: 0 }} />
            ))}
          </div>
          {([-1, 1] as const).map(dir => (
            <button key={dir} onClick={() => goTo((current + dir + SLIDES.length) % SLIDES.length)} style={{ position: 'absolute', top: '50%', transform: 'translateY(-50%)', [dir === -1 ? 'left' : 'right']: '0.75rem', background: 'rgba(255,255,255,0.15)', backdropFilter: 'blur(4px)', border: '1px solid rgba(255,255,255,0.2)', borderRadius: '50%', width: '32px', height: '32px', cursor: 'pointer', color: '#fff', fontSize: '1.1rem', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>{dir === -1 ? '‹' : '›'}</button>
          ))}
        </div>
      </div>

      <div className="page-body" style={{ maxWidth: '1100px', margin: '0 auto', padding: 'clamp(2.5rem,5vw,4rem) clamp(2rem,5vw,5rem)' }}>

        {/* ── Bio + Info ── */}
        <div className="about-bio-grid" style={{ marginBottom: '5rem' }}>
          <div>
            <p style={{ fontFamily: 'var(--font-mono)', fontSize: '0.65rem', letterSpacing: '0.2em', color: 'var(--accent)', textTransform: 'uppercase', marginBottom: '1.5rem' }}>Profile</p>
            {[['學校', siteData.institution], ['科系', siteData.title], ['Email', siteData.email], ['電話', siteData.phone], ['位置', siteData.location]].map(([label, value]) => (
              <div key={String(label)} style={{ borderTop: '1px solid var(--border)', padding: '0.85rem 0' }}>
                <p style={{ fontFamily: 'var(--font-mono)', fontSize: '0.58rem', letterSpacing: '0.15em', color: 'var(--muted)', textTransform: 'uppercase', marginBottom: '0.3rem' }}>{label}</p>
                {label === 'Email'
                  ? <a href={'mailto:' + value} style={{ fontSize: '0.88rem', color: 'var(--accent)', textDecoration: 'none' }}>{value}</a>
                  : <p style={{ fontSize: '0.88rem', color: 'var(--text)' }}>{value}</p>}
              </div>
            ))}
          </div>
          <div>
            <p style={{ fontFamily: 'var(--font-mono)', fontSize: '0.65rem', letterSpacing: '0.2em', color: 'var(--accent)', textTransform: 'uppercase', marginBottom: '1.5rem' }}>Biography</p>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
              {siteData.bio.map((p, i) => <p key={i} style={{ fontSize: '0.93rem', color: 'var(--text-2)', lineHeight: 1.9 }}>{p}</p>)}
            </div>
          </div>
        </div>

        {/* ── Education ── */}
        <div style={{ marginBottom: '5rem' }}>
          <p style={{ fontFamily: 'var(--font-mono)', fontSize: '0.65rem', letterSpacing: '0.2em', color: 'var(--accent)', textTransform: 'uppercase', marginBottom: '2.5rem' }}>Education</p>
          <div style={{ position: 'relative', paddingLeft: '2.5rem' }}>
            <div style={{ position: 'absolute', left: '4px', top: '8px', bottom: '8px', width: '1px', background: 'var(--border)' }} />
            {education.map((e, i) => (
              <div key={e.school} style={{ position: 'relative', paddingBottom: i < education.length - 1 ? '3rem' : 0, display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '2.5rem', alignItems: 'start' }}>
                <div style={{ position: 'absolute', left: '-2.5rem', top: '7px', width: '10px', height: '10px', borderRadius: '50%', background: i === 0 ? 'var(--accent)' : 'var(--bg)', border: `2px solid ${i === 0 ? 'var(--accent)' : 'var(--border-2)'}`, zIndex: 1 }} />

                {/* 左 */}
                <div>
                  <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.5rem', alignItems: 'center', marginBottom: '0.5rem' }}>
                    <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.68rem', color: 'var(--muted)' }}>{e.period}</span>
                    {e.badge && <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.58rem', padding: '0.15em 0.65em', borderRadius: '2px', background: 'var(--accent-light)', color: 'var(--accent)', border: '1px solid rgba(59,91,219,0.2)' }}>{e.badge}</span>}
                  </div>
                  <h3 style={{ fontFamily: 'var(--font-display)', fontSize: '1.3rem', fontWeight: 400, color: 'var(--text)', marginBottom: '0.25rem' }}>{e.school}</h3>
                  {e.dept && <p style={{ fontSize: '0.88rem', color: 'var(--text-2)' }}>{e.dept} — {e.degree}</p>}
                </div>

                {/* 右：highlights，標題大、內容小 */}
                {e.highlights.length > 0 && (
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '1rem 1.5rem', paddingTop: '0.1rem' }}>
                    {e.highlights.map(h => (
                      <div key={h.label}>
                        <p style={{ fontFamily: 'var(--font-display)', fontSize: '1rem', fontWeight: 400, color: 'var(--text)', marginBottom: '0.4rem' }}>{h.label}</p>
                        <ul style={{ listStyle: 'none', display: 'flex', flexDirection: 'column', gap: '0.2rem' }}>
                          {h.items.map(item => (
                            <li key={item} style={{ display: 'flex', gap: '0.5rem', alignItems: 'flex-start' }}>
                              <span style={{ color: 'var(--accent)', flexShrink: 0, fontSize: '0.65rem', marginTop: '0.3rem' }}>▸</span>
                              <span style={{ fontSize: '0.84rem', color: 'var(--text-2)', lineHeight: 1.6 }}>{item}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* ── Work Experience — 原本的 2x2 卡片 ── */}
        <div>
          <p style={{ fontFamily: 'var(--font-mono)', fontSize: '0.65rem', letterSpacing: '0.2em', color: 'var(--accent)', textTransform: 'uppercase', marginBottom: '1.75rem' }}>Work Experience</p>
          <div className="work-grid">
            {experience.map(e => (
              <div key={e.company} style={{ background: 'var(--bg)', padding: '1.75rem' }}>
                <p style={{ fontFamily: 'var(--font-mono)', fontSize: '0.6rem', color: 'var(--muted)', letterSpacing: '0.1em', textTransform: 'uppercase', marginBottom: '0.6rem' }}>{e.period}</p>
                <h4 style={{ fontFamily: 'var(--font-display)', fontSize: '1.05rem', fontWeight: 400, marginBottom: '0.15rem' }}>{e.role}</h4>
                <p style={{ fontSize: '0.82rem', color: 'var(--accent)', marginBottom: '0.5rem' }}>{e.company}</p>
                <p style={{ fontSize: '0.82rem', color: 'var(--text-2)', lineHeight: 1.7 }}>{e.desc}</p>
              </div>
            ))}
          </div>
        </div>

      </div>
    </div>
  )
}